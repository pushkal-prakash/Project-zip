$(document).ready(function() {
	$('#login').click(function() {
		location.href = "login";
	});
});