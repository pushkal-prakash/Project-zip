package mum.waa.fd.app.domain;

/**
 * <p>Gender class.</p>
 *
 * @author Toan Quach
 * @version $Id: $Id
 */
public enum Gender {

	MALE, FEMALE;
}
