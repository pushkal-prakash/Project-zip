
Class diagram
=============

Use cases
===========

![patient registration](diagrams/patient_registration.svg)
![doctor registration](diagrams/doctor_registration.svg)
![patient asks for appointment](diagrams/patient_appointment.svg)
![doctor updates the appointment](diagrams/doctor_updates_appointment.svg)
